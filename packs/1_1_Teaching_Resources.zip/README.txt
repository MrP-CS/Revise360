Revise 360 - 1.1 Systems architecture
Unit teaching resources

WHAT IS IN HERE
  One folder per lesson, numbered in teaching order. Each holds:
    the lesson PowerPoint (.pptx, editable)
    the student worksheet (.docx to edit, .pdf to print)

  5 lessons. Built 03 October 2026.


WHAT IS NOT IN HERE
  The 360-degree experiences. They are not downloadable, and this is not an
  offline version of Revise 360. PowerPoints, worksheets and teacher guides are
  downloadable; the interactive 360-degree experiences are accessed on the
  Revise 360 website.

  Teacher guides, lesson plans and answers are in the companion download,
  1_1_Teacher_Guide.zip.

USING THEM
  The slides are for the front of the room, the worksheet is for writing and for
  the record, and the experience on the website is where a pupil is marked. The
  rule that holds them together is: write first, then answer at the badge.

Revise 360 - a product of Revise 360 Ltd, created by Olly Pettitt.
An independent resource: not written, endorsed or approved by OCR or any exam
board. Classroom use and personal study only.
