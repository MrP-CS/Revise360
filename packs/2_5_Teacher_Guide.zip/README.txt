Revise 360 - 2.5 Programming languages and IDEs
Unit teacher guide

WHAT IS IN HERE
  2_5_Unit_Pedagogy.pdf        why this unit is taught in this order, what is hard
                 about it, and where support fades
  2_5_Unit_Big_Picture.pdf        where the unit sits, what it covers and how far
  2_5_Unit_Delivery_Guide.pdf        how to run it, with every lesson summarised
  GCSE_Course_Big_Picture.pdf   all the units across the specification
  Lesson_Plans/  a plan for every lesson in the unit, one PDF each
  Teacher_Answers/  marking guidance, where verified answers exist

  5 lesson plans. Built 03 October 2026.

WHAT IS NOT IN HERE
  The 360-degree experiences. They are not downloadable, and this is not an
  offline version of Revise 360. PowerPoints, worksheets and teacher guides are
  downloadable; the interactive 360-degree experiences are accessed on the
  Revise 360 website.

  The slides and worksheets are in the companion download, 2_5_Teaching_Resources.zip.

A NOTE ON ANSWERS
  Model answers are not printed on the lesson plans. A plan is printed and left
  on a desk; an answer sheet is not.
  There are no verified teacher answers for this unit yet, so this
  pack has no Teacher_Answers folder rather than an empty one.

Revise 360 - a product of Revise 360 Ltd, created by Olly Pettitt.
An independent resource: not written, endorsed or approved by OCR or any exam
board. Classroom use and personal study only.
